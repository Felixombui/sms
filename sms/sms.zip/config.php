<?php
$db_server='macrasystems.com';
$db_user='macrasys';
$db_pass='playgroundkasa2015';
$dbase='macrasys_smsserver';
$config=mysqli_connect($db_server,$db_user,$db_pass,$dbase);
if(!$config){
    echo 'Error! Connection Failed. Contact admin';
}
?>