<?php
include 'headers.php';
include 'styles.html';
echo 'Below are the rates.';

?>
<table><tr><td>SMS Amount</td><td>Cost(Ksh)</td></tr>
<tr><td>0-999</td><td>Not Applicable</td></tr>
<tr><td>1000-2500</td><td>1.00</td></tr>
<tr><td>2600-5000</td><td>0.90</td></tr>
<tr><td>5001-7500</td><td>0.80</td></tr>
<tr><td>7501-10000</td><td>0.70</td></tr>
<tr><td>Over 10000</td><td>0.60</td></tr>
</table>
Send your Amount to 0708138498 via mpesa