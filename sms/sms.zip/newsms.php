<?php
include 'headers.php';
if($_POST['send']){
    $phonenumbers=addslashes($_POST['phonenumbers']);
    $message=addslashes($_POST['message']);
    if(empty($phonenumbers)){
        $err='<img src="images/error.png" width="20" height="20"> Error! Please enter at least 1 phone number.';
    }else{
        if(empty($message)){
            $err='<img src="images/error.png" width="20" height="20"> Error! Please type a message.';
        }else{
            $senderid=$_SESSION['senderid'];
            $message=urlencode($message);
            $url='http://sms.macrasystems.com/sendsms/index.php?username='.$username.'&senderid='.$senderid.'&phonenumber='.$phonenumbers.'&message='.$message.'';
            file_get_contents($url);
            $err='<img src="images/success.png" width="20" height="20"> Message sent successfully.';
        }
    }
}
?>
<table width="100%"  align="left"><tr><td align="left">
    <form name="import" method="post">Import from CSV:<input type="file" name="file"></form> Or
    <form action="" method="post">
        <table width="50%"><tr><td><input type="text" name="phonenumbers" placeholder="Phone numbers separated with comma. e.g 254701123456"></td></tr>
        <tr><td><textarea name="message" placeholder="Type Message here..."></textarea></td></tr>
        <tr><td><input type="submit" name="send" value="Send Message"></td></tr>
        <tr><td><?php echo $err ?></td></tr>
    </table>
    </form>
</td></tr></table>