<?php
include 'headers.php';
?>
<table width="100%"><tr><td align="center">
    <div class="numberreport"><p>SMS Balance </p><?php echo $smsbalance ?><br><a href="buysms01.php">Buy SMS</a></div>
</td></tr></table>