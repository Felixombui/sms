<?php
session_start();
if(empty($_SESSION['customername'])){
    header('location:login.php');
}
include 'config.php';
include 'styles.html';
$username=$_SESSION['customername'];
$balqry=mysqli_query($config,"SELECT * FROM smscounter WHERE username='$username'");
if(mysqli_num_rows($balqry)>0){
    $balrow=mysqli_fetch_assoc($balqry);
    $smsbalance=$balrow['availablebalance'];
}else{
    $smsbalance='0';
}
$msgqry=mysqli_query($config,"SELECT * FROM messages WHERE sender='$username'");
$messages=mysqli_num_rows($msgqry);
?>
<table class="heading" width="100%"><tr><td align="left">
   <img src="images/user.png" width="20" height="20" align="left"><?php echo $_SESSION['customername'] ?> [<a href="logout.php">Logout</a>]
</td>
<td width="27%"><a href="messages.php">Sent Messages<br><img src="images/icons/email.ico" width="18" height="18" align="left"><?php echo $messages ?></a></td>
<td width="25%"><a href="buysms01.php">SMS Balance <br><img src="images/AddDB.png" width="25" height="25" align="left"><?php echo $smsbalance ?></a></td>

</tr></table>
<p>